/**********************************
Programmer: HABIBUR RAHMAN HABIB;
Date: th ,2013;
About: ;
***********************************/
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
int main()
{

    return 0;
}
