#include<stdio.h>
int main()
{
int i,j,n;
i=10, j=15;
i = (i+j)-(j=i);
printf("%d %d\n",i,j);
return 0;
}
