//BISMILLAHIR RAHMANIR RAHIM
//RABBI JIDNI ELMAN
#include<cstdio>
#include<sstream>
#include<cstdlib>
#include<cctype>
#include<cmath>
#include<algorithm>
#include<set>
#include<queue>
#include<stack>
#include<list>
#include<iostream>
#include<fstream>
#include<numeric>
#include<string>
#include<vector>
#include<cstring>
#include<map>
#include<iterator>
using namespace std;
//#define MAX
//#define LMT
#define ll long long int

int main()
{
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
    char str[1010];
    int i;
    set<char>ss;
    gets(str);
        for(i=0;i<str[i];i++)
        {
            if(str[i]>='a'&&str[i]<='z')
            {
                ss.insert(str[i]);
            }
        }
        printf("%d\n",ss.size());
    return 0;
}
